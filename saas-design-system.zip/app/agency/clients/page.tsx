import { ClientManagement } from "@/components/agency/client-management"

export default function ClientsPage() {
  return <ClientManagement />
}
