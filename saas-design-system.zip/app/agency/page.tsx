import { AgencyDashboard } from "@/components/agency/dashboard"

export default function AgencyDashboardPage() {
  return <AgencyDashboard />
}
