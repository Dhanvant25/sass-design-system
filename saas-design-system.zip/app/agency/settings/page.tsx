import { AgencySettings } from "@/components/agency/settings"

export default function AgencySettingsPage() {
  return <AgencySettings />
}
