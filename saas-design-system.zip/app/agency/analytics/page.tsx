import { AgencyAnalytics } from "@/components/agency/analytics"

export default function AnalyticsPage() {
  return <AgencyAnalytics />
}
