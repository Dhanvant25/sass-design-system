import { AgencyBranding } from "@/components/agency/branding"

export default function BrandingPage() {
  return <AgencyBranding />
}
