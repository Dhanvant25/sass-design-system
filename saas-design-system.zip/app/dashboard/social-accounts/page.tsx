import { SocialAccountsPage } from "@/components/dashboard/social-accounts"

export default function SocialAccounts() {
  return <SocialAccountsPage />
}
