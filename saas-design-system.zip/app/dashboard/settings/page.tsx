import { SettingsPage } from "@/components/dashboard/settings"

export default function Settings() {
  return <SettingsPage />
}
