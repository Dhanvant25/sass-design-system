import { AssetLibraryPage } from "@/components/dashboard/asset-library"

export default function AssetLibrary() {
  return <AssetLibraryPage />
}
