import { ContentPlannerPage } from "@/components/dashboard/content-planner"

export default function ContentPlanner() {
  return <ContentPlannerPage />
}
